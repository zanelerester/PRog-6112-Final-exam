/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mattress;

/**
 *
 * @author Student
 */

import java.util.Scanner;
public class Mattress {
public static void main(String[] args) {
Scanner input = new Scanner(System.in);
// Single-dimensional array
String[] productNames = {
"Cozy Nights Monarch",
"Restonic Barbados",
"Sealy Phuket"
};
// Two-dimensional array
int[][] sales = new int[3][3];
// Capture monthly sales
for (int i = 0; i < productNames.length; i++) {
for (int j = 0; j < 3; j++) {
System.out.print("Enter number of sales for month "
+(j + 1) + " for "
+ productNames[i] + " mattress: ");
while (!input.hasNextInt()) {
System.out.println("Please enter a valid number.");
input.next();
System.out.print("Enter sales again: ");
}
int quantity = input.nextInt();
while (quantity < 0) {
System.out.println("Sales cannot be negative.");
System.out.print("Enter sales again: ");
while (!input.hasNextInt()) {
System.out.println("Please enter a valid number.");
input.next();
System.out.print("Enter sales again: ");
}
quantity = input.nextInt();
}
sales[i][j] = quantity;
}
System.out.println();
}
// Create Product object

Product product = new Product(productNames, sales);

PrintProduct report = new PrintProduct();


report.PrintReport(product);
input.close();
}
}

