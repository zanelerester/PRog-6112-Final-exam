/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mattresssalesapp;

/**
 *
 * @author Student
 */


public class ProductCalculations implements IProductCalculations {

    private double productPrice;

    // Constructor
    public ProductCalculations(double productPrice) {
        this.productPrice = productPrice;
    }

    // Calculate VAT (15%)
    @Override
    public double GetVat() {
        return productPrice * 0.15;
    }

    // Calculate Commission (5%)
    @Override
    public double GetCommission() {
        return productPrice * 0.05;
    }

    // Calculate Total Sale Amount
    @Override
    public double GetTotal() {
        return productPrice + GetVat() + GetCommission();
    }

}